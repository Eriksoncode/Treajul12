let modal = document.getElementById("modal");
let guardarBtn = document.getElementById('guardarBtn');

function mostrarModal() {
  modal.style.display = "block";
}

function cerrarModal() {
  modal.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
    cerrarModal();
  }
}

// redireccionar a la página con el mensaje
guardarBtn.addEventListener('click', function() {
  window.location.href = '/successPage/success.html';
});
